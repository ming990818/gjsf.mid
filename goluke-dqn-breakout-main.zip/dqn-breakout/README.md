DQN for Breakout
================

This project is modified from https://github.com/wetliu/dqn_pytorch based on my
opinionated styles of coding.

And here are some pre-trained weights that you can play with:
- [model_weights_a](https://github.com/lukeluocn/dqn-breakout/releases/download/v0.0.0/model_weights_a)
- [model_weights_b](https://github.com/lukeluocn/dqn-breakout/releases/download/v0.0.0/model_weights_b)
